// import logo from './logo.svg';
// import {BrowserRouter,Routes,Route} from 'react-router-dom';
import './App.css';
import Navbar from './Component/Navbar';
import Form from './Component/Form';
import { BrowserRouter, Routes, Route, Link }from 'react-router-dom';
import About from './Component/About';
import Home from './Component/Home';




function App() {
  return (
    <>
      <BrowserRouter>
      <Navbar title="Online Quiz" login="Login" about="About"/>
        <Routes>
          <Route exact path='/' element={<Home />} />
          <Route exact path='login' element={<Form />} />
          <Route exact path = 'about' element={<About/>} />
        </Routes>
      </BrowserRouter>
      
      {/*
      <Form/> */}
    </>
  );
}

export default App;
