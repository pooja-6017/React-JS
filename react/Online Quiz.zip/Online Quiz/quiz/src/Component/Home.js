import React from 'react'
import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <>
    <div>
      <h1 className='container center my-5 ' >Welcome to Online Quiz</h1>
      <div className='container col-3 mb-3'>
        {/* <button type="button" className="btn btn-success col-3 mx-3 ">Student</button>
        <button type="button" className="btn btn-primary col-3 mx-3">Teacher</button> */}
        <div className="card my-4" style={{width:"18rem"}}>
          <div className="card-body">
            <h5 className="card-title">Student</h5>
            <a href="/" className="btn btn-primary">Login</a>
          </div>
        </div>

        <div className="card" style={{width:"18rem"}}>
          <div className="card-body">
            <h5 className="card-title">Teacher</h5>
            <a href="/" className="btn btn-primary">Login</a>
          </div>
        </div>
      </div>
    </div>
    </>
  )
}
